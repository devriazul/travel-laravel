## NOMADS Travel Agency Web
Project for learning laravel framework

# Components
- Laravel Framework
- Bootstrap 4

# Features
1. User Dashboard Panel
2. User Authentication
3. Admin Panel

# Screenshoot
<img src="https://github.com/wibichamim/Laravel-TravelWeb/blob/master/ss/1.png">&nbsp; <br>
<img src="https://github.com/wibichamim/Laravel-TravelWeb/blob/master/ss/2.png">&nbsp; <br>
<img src="https://github.com/wibichamim/Laravel-TravelWeb/blob/master/ss/3.png">&nbsp; <br>
<img src="https://github.com/wibichamim/Laravel-TravelWeb/blob/master/ss/4.png">&nbsp; <br>
<img src="https://github.com/wibichamim/Laravel-TravelWeb/blob/master/ss/5.png">&nbsp; <br>
<img src="https://github.com/wibichamim/Laravel-TravelWeb/blob/master/ss/6.png">&nbsp; <br>
<img src="https://github.com/wibichamim/Laravel-TravelWeb/blob/master/ss/7.png">&nbsp; <br>
<img src="https://github.com/wibichamim/Laravel-TravelWeb/blob/master/ss/8.png">&nbsp; <br>
<img src="https://github.com/wibichamim/Laravel-TravelWeb/blob/master/ss/9.png">&nbsp; <br>

